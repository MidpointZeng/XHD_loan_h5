window.globalConfig = {
    isLocalData: false, //是否使用本地数据。
}